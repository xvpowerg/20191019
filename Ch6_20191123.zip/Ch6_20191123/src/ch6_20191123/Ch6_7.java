/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191123;

/**
 *
 * @author xvpow
 */
public class Ch6_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal anim = new Dog("KaKa",5,20);
        System.out.println(anim);
        anim.skill();
    }
    
}
