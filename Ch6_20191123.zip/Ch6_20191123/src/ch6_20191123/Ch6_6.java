/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191123;

/**
 *
 * @author xvpow
 */
public class Ch6_6 {


    public static void main(String[] args) {
       
        Parnet2 p2 = new Sub2();
        p2.setValue1(20);
        System.out.println(p2.value1);
        p2.test();
        
    }
    
}
