/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191214;
import java.util.ArrayList;
public class Ch9_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList list = new ArrayList();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D"); 
        
//        for (int i = 0; i < list.size();i++){
//            System.out.print(list.get(i)+" ");
//        }
        
//        for (Object obj : list){
//            System.out.print(obj+" ");
//        }

       // list.forEach(System.out::println);//java 8
        

       
        
    }
    
}
