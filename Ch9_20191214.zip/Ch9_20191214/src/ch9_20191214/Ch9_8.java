/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191214;

import java.util.LinkedList;

/**
 *
 * @author xvpow
 */
public class Ch9_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          LinkedList<String> list = new LinkedList<>();
          String v1 = list.poll();
          System.out.println(v1);
         // list.remove();
         String v2 = list.peek();
         list.element();
          
    }
    
}
