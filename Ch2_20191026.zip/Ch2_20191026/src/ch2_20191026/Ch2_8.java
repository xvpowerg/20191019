/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191026;

/**
 *
 * @author xvpow
 */
public class Ch2_8 {
   static void test1(int x){
       int y = 10;
       System.out.printf("Test1 x:%d y:%d %n",x,y);
   }
   
   static void test2(int x){
       int y = 62;
      System.out.printf("Test2 x:%d y:%d %n",x,y);  
   }
    public static void main(String[] args) {
        // TODO code application logic here
       test1(32);
       test2(51);
    }
    
}
