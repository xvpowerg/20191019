/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191130;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {
    
    public static void main(String[] args) {
       MyButton btn = new MyButton(0,0);
      // btn.onClick();
       System.out.println(MyComparetor.max(2, 5));
    }
    
}
