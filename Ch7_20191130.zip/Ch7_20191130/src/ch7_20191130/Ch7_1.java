/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191130;

/**
 *
 * @author xvpow
 */
public class Ch7_1 {

    public static void main(String[] args) {
      SuperSkill skill = new Vegeta(); 
        skill.attacking(5000);
        skill.flying(100000);
        skill.jumping(10);
        
        
    }
    
}
