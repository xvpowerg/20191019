
package ch7_20191130;

public interface Fly {
    //介面屬性預設為public static final
    float MAX_SPEED = 5000;
    void flying(float speed);
}
