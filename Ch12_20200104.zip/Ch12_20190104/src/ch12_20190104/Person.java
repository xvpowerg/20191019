/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190104;

import java.io.Serializable;

/**
 *
 * @author xvpow
 */
public class Person implements Serializable{
    public Person(String v1){
	
    }
}
