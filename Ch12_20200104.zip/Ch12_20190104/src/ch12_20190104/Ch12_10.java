/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20190104;

/**
 *
 * @author xvpow
 */
public class Ch12_10 {

   
    public static void main(String[] args) {
	
	int a = 10;
	int b = 3;
	//不等於0才會觸發
	assert a % b == 0 : "a除b未整除";
	
	
    }
    
}
