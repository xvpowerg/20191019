package ch3_20191102;
public class Ch3_5 {

    public static void main(String[] args) {
       
        TestConstructor tc = new TestConstructor(51,"Test0");
        
        
    }
    
}
