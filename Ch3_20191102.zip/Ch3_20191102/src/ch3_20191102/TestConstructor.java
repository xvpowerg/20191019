/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

/**
 *
 * @author shihhaochiu
 */
public class TestConstructor {
    
    TestConstructor(){
          this(1.5f,25,"Test1");
        System.out.println("TestConstructor()");
    }
    
    TestConstructor(int a,String s){
        this();
       System.out.printf("TestConstructor(%d,%s)%n",a,s); 
    }
    
    TestConstructor(float  f,int a ,String s){
              System.out.printf("TestConstructor(%f,%d,%s)%n",f,a,s);  
    }
    
    
}
