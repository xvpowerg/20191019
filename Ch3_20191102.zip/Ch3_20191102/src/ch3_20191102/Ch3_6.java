/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

/**
 *
 * @author shihhaochiu
 */
public class Ch3_6 {

    public static void main(String[] args) {
        
        Animal an1=  new Animal("BoBo",5,6);
        an1.print();
        
        Dog dog1 = new Dog();
        dog1.setName("NiNi");
        dog1.setHeight(2);
        dog1.setAge(1);
        dog1.print();
       
        Dog dog2 = new Dog("yumi",5,20);
        dog2.print();
        
        Cat cat1 = new Cat("Kitty",20,30);
        cat1.print();
        
        
        
    }
    
}
