/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

public class Ch3_4 {

    public static void main(String[] args) {
       Student st1 = new  Student(10,"Ken");
       st1.print();
       st1.appendScore(50);
       st1.appendScore(93);
       st1.appendScore(76);
       st1.appendScore(89);
       st1.printScore();
       //沒有成績可顯示時顯示無成績
       //appendScore 附加成績最多3筆
       
       System.out.println("==================");
       Student st2 = new  Student();
       st2.print();
       st2.printScore();
       
    }
    
}
