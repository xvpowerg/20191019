/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

/**
 *
 * @author shihhaochiu
 */
public class Ch3_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //多型 Polymorphism
        Animal dog = new Dog("Sonpy",50,10);
        Animal cat = new Cat("DoRaMo",40,110);
        dog.print();
        cat.print();
    }
    
}
