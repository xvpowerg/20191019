/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

public class Ch3_1 {

   
    public static void main(String... args) {
        for (int i =0;i<args.length ;i++){
         System.out.printf("%d-%s %n",i,args[4]);
        }
    }
    
}
