/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;

/**
 *  
 * @author shihhaochiu
 */
public class Ch3_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Toy toy = new Toy("Irirs",6500,"PVC");
        toy.print();
        
    }
    
}
