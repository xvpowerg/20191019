/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191102;


public class Ch3_othr {
    
    static boolean test1(boolean r){
        System.out.println("Test1");
        return r;
    }
        static boolean test2(boolean r){
        System.out.println("Test2");
        return r;
    }
    public static void main(String[] args) {
        //只要左邊true 右邊就不執行
        boolean b1 = test1(true) || test2(true);
        System.out.println(b1);
           boolean b2 = test1(false) || test2(true);
           System.out.println(b2);
         System.out.println("================");  
         
        boolean b3 = test1(true) && test2(true);
        System.out.println(b3);
        //只要左邊為false 右邊就不執行
         boolean b4 = test1(false) && test2(true);
        System.out.println(b4);
        
    }
    
}
