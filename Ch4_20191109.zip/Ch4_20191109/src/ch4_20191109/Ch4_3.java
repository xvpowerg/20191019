/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20191109;

/**
 *
 * @author shihhaochiu
 */
public class Ch4_3 {
     public static void main(String[] args){
         TestModfily tm = new TestModfily();
        System.out.println(tm.publicValue); 
        System.out.println(tm.protectedValue); 
          System.out.println(tm.defaultValue); 
     }
}
