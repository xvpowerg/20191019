/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20191109;

/**
 *
 * @author shihhaochiu
 */
public class TestModfily {
    public String publicValue = "TestModfily Public";
    protected  String protectedValue = "TestModfily protected ";
    protected String defaultValue = "TestModfily defaultValue";
    private String privateValue = "private value";
}
